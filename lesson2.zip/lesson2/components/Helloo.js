import React from 'react';

export default function Helloo(props){
    return(
        <div>
            Hello, {props.name}!
        </div>
    );
}