import React,{useState} from 'react';

export default function ListSingleItem02(props){
    const [isShown,setIsShown] = useState(false);

    return(
        <>
            <div>
                <span>
                    {props.name} {props.lastName}
                </span>
                <button onClick={() => {
                    setIsShown(!isShown)
                }}>Show Desc</button>
            </div>
            
            {isShown && // WHEN THIS IS TRUE SHOW DESCRIPTION
            <div>
                {props.description}
            </div>
            }
        </>
    )
}
