import React from 'react';

export default function Listt(props){


    function renderLi(item,index){
        return(
            <li>
                <span>
                {item}
                </span>
                <button onClick={() => {
                    props.delete(index) // TOZI INDEX SE PODAWA KYM APP09 -> red 32
                }}>X</button>
            </li>
        );
    }

    return(
        <>
            <ul>
                {props.items.map(renderLi)}
            </ul>
        </>            
    );
}