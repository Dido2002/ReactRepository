import React,{useState} from 'react';
import ListSingleItem02 from './ListSingleItem02';

export default function Listtt(props){
    return(
    <div>
        {props.items.map(item => 
        <ListSingleItem02
            name = {item.name}
            lastName = {item.lastName}
            description = {item.description}
            item = {item}
        />)}
    </div>
    );
}