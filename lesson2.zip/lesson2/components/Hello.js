import React from 'react';

export default function Hello(){
    return(
        <div>Hello how are you?</div>
    )
}