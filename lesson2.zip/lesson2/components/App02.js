import React, {useState} from 'react';
import './App02.css';
export default function App02(){
    const [items,setItems] = useState(['Item 1','Item 2', 'Item 3']);
    const [isHighlighted, setIsHighlighted] = useState([false,false,false]);

    function handleClick(index){
        isHighlighted[index] = !isHighlighted[index];
        setIsHighlighted([...isHighlighted]);
    }
    return(
        <div>

            <ul>
                {items.map((item,index) => 
                <li className={isHighlighted[index] ? 'bg-blue': ''}
                key={index}  onClick={() => {handleClick(index)}}>{item} - {index}</li>)}
            </ul>
        </div>
    )
}