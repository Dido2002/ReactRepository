import React, {useState} from 'react';
import './App01.css';
import Hello from './Hello.js';

export default function App01(){
    const [isShown, setIsShown] = useState(false);
    return(
        <div>
            <button onClick={()=>{
                setIsShown(!isShown);
            }}>Click</button>
            {isShown && <Hello/>}
        </div>
    );

}