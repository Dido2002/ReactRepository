import React, {useState} from 'react';

export default function App(){
    const [state, setState] = useState('off');
    return(
        <div>
            <button style={{color: state == 'on' ? 'green' : 'red'}
        }
        onClick={()=>{
            if(state == 'off')
            {
                setState('on');
            }
            else{
                setState('off');
            }
        }}>{state}</button>
        </div>

    );
}